create table FactTransaction(
transactionID int,
accountKey int foreign key references DimAccount(accountSK),
clientKey int foreign key references DimClient(clientSK),
loanKey int foreign key references DimLoan(loanSK),
standingOrderKey int foreign key references DimStandingOrder(standingOrderSK),
dispositionKey int foreign key references DimDisposition(dispositionSK),
dateKey int foreign key references DimDate(DateKey),
type varchar(100),
amount numeric(38,0),
balance numeric(38,0),
operation varchar(100),
bank varchar(50),
accm_txn_create_time datetime,
accm_txn_complete_time datetime,
txn_process_time_hours int,
ModifiedDate datetime
)