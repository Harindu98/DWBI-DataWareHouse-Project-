create table DimCard(
cardSK int identity(1,1) primary key,
alternateCardID int,
dispositionKey int foreign key references DimDisposition(dispositionSK),
type nvarchar(60),
issuedDate date,
InsertDate datetime,
ModifiedDate datetime
)